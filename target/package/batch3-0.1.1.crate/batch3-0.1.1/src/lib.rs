pub mod islamabad {
    pub fn piaic() {
        println!("Batch3 Islamaabad PIAIC");
    }
}
